#!/usr/bin/env bash

# Place the sherpa script into the user's binaries folder
cp ./sherpa /usr/local/bin/

# Discover Pi's IP Addr

# Extract Subnet Mask
subnet=$((ifconfig | grep -A1 "wlan0" || ifconfig | grep -A1 "en0") | grep -oE "inet \b([0-9]{1,3}\.){3}[0-9]{1,3}\b" | grep -oE "\b([0-9]{1,3}\.){3}\b")

piip=$(sudo nmap -sP -PS22,3389 "$subnet"1/24 2> /dev/null || (brew update && brew install nmap && sudo nmap -sP -PS22,3389 "$subnet"1/24))
echo "$piip"
PIIP=$(echo "$piip" | grep -B2 "Raspberry")

echo "$PIIP"